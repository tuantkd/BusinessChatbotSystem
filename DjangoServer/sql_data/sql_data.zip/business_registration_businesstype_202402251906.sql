INSERT INTO public.business_registration_businesstype (type_description) VALUES
	 ('Công ty trách nhiệm hữu hạn một thành viên'),
	 ('Công ty cổ phần'),
	 ('Công ty hợp danh'),
	 ('Doanh nghiệp tư nhân'),
	 ('Công ty trách nhiệm hữu hạn hai thành viên trở lên');
